# VeriSMA — Pusat Cek Fakta & Edukasi Anti-Hoaks Siswa SMA

Proyek website edukasi literasi digital bertema **Pusat Cek Fakta dan Edukasi Anti-Hoaks Siswa SMA** dengan tampilan gelap modern (`#121212`), aksen gradasi pink cerah (`#FF2E93`) dan oranye cerah (`#FF7A00`), ornamen bunga SVG melayang, animasi interaktif, serta integrasi pelaporan ke Google Sheets.

## Struktur Berkas

```text
pusat-cek-fakta-sma/
├── index.html          # Struktur utama halaman (Hero, Info Awal, Cek Hoaks, Edukasi/Kuis, Referensi, Lapor)
├── style.css           # Styling responsif, tema #121212, gradasi #FF2E93 -> #FF7A00, animasi SVG & tab
├── script.js           # Logika login localStorage, simulasi analisis teks, kuis interaktif, & fetch POST
├── Code.gs             # Kode Google Apps Script (doPost) siap pakai untuk Google Sheets
└── README.md           # Dokumentasi proyek dan panduan deployment
```

## Fitur Utama

1. **Informasi Awal Lengkap**: Memuat judul website, latar belakang masalah hoaks di kalangan pelajar, tujuan proyek, sasaran pengguna, dan petunjuk penggunaan.
2. **Login Simulasi Aman (`localStorage`)**: Dilengkapi tombol **Isi Data Contoh Siswa** agar siswa dapat mencoba fitur personalisasi tanpa memasukkan data pribadi asli.
3. **Alat Cek Hoaks Cepat `[SIMULASI PROTOTIPE AI]`**: Menganalisis teks berita/pesan berantai berdasarkan deteksi kata provokatif, huruf kapital berlebihan, tanda seru beruntun, dan rujukan sumber resmi, lengkap dengan label edukasi yang transparan.
4. **Edukasi & Kuis Interaktif**: Navigasi tab dengan transisi halus berisi materi ciri-ciri hoaks, langkah pencegahan, dan 5 soal kuis literasi digital beserta pembahasan.
5. **Direktori Cek Fakta Nyata**: Tautan langsung ke **TurnBackHoax.id**, **Google Fact Check Explorer**, **CekFakta.com**, dan **Komdigi**.
6. **Formulir Lapor Hoaks ke Google Sheets**: Mengirim laporan via `fetch()` ke Google Apps Script tanpa memerlukan API key rahasia di sisi frontend.

## Cara Menjalankan Website Secara Lokal

1. Ekstrak seluruh isi file ZIP ke dalam satu folder.
2. Buka berkas `index.html` langsung menggunakan peramban (Chrome, Edge, Firefox, atau Safari), atau jalankan menggunakan ekstensi **Live Server** di VS Code.

## Cara Menghubungkan Formulir ke Google Sheets (Tanpa API Key)

1. Buat **Google Spreadsheet** baru di Google Drive Anda.
2. Klik menu **Ekstensi (Extensions)** > **Apps Script**.
3. Hapus kode bawaan di editor Apps Script, lalu salin seluruh isi berkas `Code.gs` ke dalamnya dan simpan (`Ctrl + S`).
4. Klik tombol **Terapkan (Deploy)** > **Deployment baru (New deployment)**.
5. Pada bagian *Pilih jenis (Select type)*, pilih **Aplikasi web (Web app)**.
6. Atur konfigurasi berikut:
   - **Jalankan sebagai (Execute as)**: `Saya (Me)`
   - **Yang memiliki akses (Who has access)**: `Siapa saja (Anyone)`
7. Klik **Terapkan (Deploy)**, berikan izin akses saat diminta, lalu salin **URL Aplikasi Web** yang muncul.
8. Buka berkas `script.js`, cari baris:
   ```javascript
   const APPS_SCRIPT_URL = "URL_APPS_SCRIPT_ANDA";
   ```
   Ganti `"URL_APPS_SCRIPT_ANDA"` dengan URL Web App yang baru saja Anda salin.
