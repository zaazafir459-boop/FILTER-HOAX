/**
 * ============================================================================
 * GOOGLE APPS SCRIPT — PENERIMA LAPORAN HOAKS SISWA SMA (VeriSMA)
 * ============================================================================
 * File ini dipasang pada Google Sheets melalui menu:
 * Ekstensi (Extensions) > Apps Script
 *
 * Keunggulan:
 * - Tidak membutuhkan API Key rahasia di kode HTML/JavaScript frontend.
 * - Otomatis membuat header kolom jika sheet masih kosong.
 * - Mendukung request POST (fetch) dari website statis (GitHub Pages/Netlify/lokal).
 * ============================================================================
 */

// Nama tab sheet di Google Sheets tempat menyimpan laporan
const SHEET_NAME = "Laporan_Hoaks";

/**
 * Fungsi doPost(e) otomatis dipanggil saat website mengirim data via fetch POST.
 * @param {Object} e - Event object berisi payload JSON pada e.postData.contents
 * @returns {ContentService.TextOutput} Respon JSON ke frontend
 */
function doPost(e) {
  // LockService mencegah tabrakan data jika beberapa siswa melapor bersamaan
  const lock = LockService.getScriptLock();
  lock.tryLock(10000);

  try {
    // 1. Pastikan payload tersedia
    if (!e || !e.postData || !e.postData.contents) {
      return createJsonResponse({
        status: "error",
        message: "Payload data tidak ditemukan."
      });
    }

    // 2. Parse data JSON dari frontend
    const data = JSON.parse(e.postData.contents);

    // 3. Buka spreadsheet aktif & siapkan sheet tujuan
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName(SHEET_NAME);

    if (!sheet) {
      sheet = ss.insertSheet(SHEET_NAME);
    }

    // 4. Buat baris header otomatis jika baris pertama masih kosong
    if (sheet.getLastRow() === 0) {
      const headers = [
        "Timestamp Server",
        "Waktu Input Siswa",
        "Nama Pelapor",
        "Kelas / Sekolah",
        "Platform Sumber",
        "Kategori Hoaks",
        "Tautan Konten",
        "Ringkasan Isi Laporan",
        "Status Verifikasi"
      ];
      sheet.appendRow(headers);

      // Beri gaya tebal pada header
      sheet.getRange(1, 1, 1, headers.length).setFontWeight("bold");
      sheet.setFrozenRows(1);
    }

    // 5. Susun baris data baru sesuai urutan kolom header
    const newRow = [
      new Date(), // Timestamp otomatis dari server Google
      sanitizeText(data.waktu),
      sanitizeText(data.nama),
      sanitizeText(data.kelas),
      sanitizeText(data.platform),
      sanitizeText(data.kategori),
      sanitizeText(data.tautan),
      sanitizeText(data.isi_laporan),
      "Menunggu Tinjauan Tim" // Status default untuk moderator OSIS/Guru
    ];

    // 6. Tambahkan baris ke Google Sheets
    sheet.appendRow(newRow);

    // 7. Kembalikan respons sukses ke website
    return createJsonResponse({
      status: "success",
      message: "Laporan berhasil disimpan ke Google Sheets."
    });

  } catch (err) {
    return createJsonResponse({
      status: "error",
      message: "Kesalahan server Apps Script: " + err.toString()
    });
  } finally {
    lock.releaseLock();
  }
}

/**
 * Fungsi doGet(e) opsional untuk mengecek apakah Web App aktif saat dibuka di browser.
 */
function doGet() {
  return createJsonResponse({
    status: "active",
    service: "API Penerima Laporan Hoaks VeriSMA siap menerima request POST."
  });
}

/**
 * Helper untuk mencegah formula injection sederhana di spreadsheet
 */
function sanitizeText(value) {
  if (value === null || value === undefined) return "-";
  const str = String(value).trim();
  if (str.startsWith("=") || str.startsWith("+") || str.startsWith("-") || str.startsWith("@")) {
    return "'" + str;
  }
  return str || "-";
}

/**
 * Helper untuk membentuk respons JSON standar
 */
function createJsonResponse(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
