/**
 * VeriSMA — Pusat Cek Fakta & Edukasi Anti-Hoaks Siswa SMA
 * Fitur:
 * 1. Login Simulasi berbasis localStorage + Tombol Data Contoh Siswa
 * 2. Simulasi Prototipe AI Cek Hoaks & Deteksi Kata Provokatif
 * 3. Navigasi Tab Edukasi Mulus & Kuis Interaktif
 * 4. Pengiriman Laporan Hoaks via fetch() ke Google Apps Script
 */

// Ganti placeholder di bawah dengan URL Web App Google Apps Script Anda setelah deploy
const APPS_SCRIPT_URL = "URL_APPS_SCRIPT_ANDA";

document.addEventListener("DOMContentLoaded", () => {
  initSimulatedAuth();
  initHoaxChecker();
  initTabs();
  initQuiz();
  initReportForm();
});

/* =========================================================
   1. LOGIN SIMULASI BERBASIS LOCALSTORAGE
   ========================================================= */
function initSimulatedAuth() {
  const STORAGE_KEY = "verisma_sim_student";
  const openLoginBtn = document.getElementById("openLoginBtn");
  const logoutBtn = document.getElementById("logoutBtn");
  const loginModal = document.getElementById("loginModal");
  const closeLoginModalBtn = document.getElementById("closeLoginModalBtn");
  const fillDemoStudentBtn = document.getElementById("fillDemoStudentBtn");
  const simLoginForm = document.getElementById("simLoginForm");
  const userStatusBadge = document.getElementById("userStatusBadge");

  const nameInput = document.getElementById("studentNameInput");
  const classInput = document.getElementById("studentClassInput");
  const schoolInput = document.getElementById("studentSchoolInput");

  function renderAuthState() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const user = JSON.parse(saved);
      userStatusBadge.textContent = `${user.name} (${user.kelas})`;
      userStatusBadge.classList.remove("hidden");
      openLoginBtn.classList.add("hidden");
      logoutBtn.classList.remove("hidden");

      // Isi otomatis kolom pelapor jika masih kosong
      const reporterName = document.getElementById("reporterName");
      const reporterClass = document.getElementById("reporterClass");
      if (reporterName && !reporterName.value) reporterName.value = user.name;
      if (reporterClass && !reporterClass.value) {
        reporterClass.value = `${user.kelas} - ${user.school}`;
      }
    } else {
      userStatusBadge.classList.add("hidden");
      openLoginBtn.classList.remove("hidden");
      logoutBtn.classList.add("hidden");
    }
  }

  openLoginBtn.addEventListener("click", () => {
    loginModal.classList.remove("hidden");
  });

  closeLoginModalBtn.addEventListener("click", () => {
    loginModal.classList.add("hidden");
  });

  loginModal.addEventListener("click", (e) => {
    if (e.target === loginModal) loginModal.classList.add("hidden");
  });

  // Tombol isi data contoh agar siswa tidak perlu memakai data pribadi asli
  fillDemoStudentBtn.addEventListener("click", () => {
    const sampleProfiles = [
      { name: "Nadia Putri (Contoh)", kelas: "XI IPA 2", school: "SMAN 1 Nusantara" },
      { name: "Dimas Pratama (Contoh)", kelas: "X-5", school: "SMA Cendekia Bangsa" },
      { name: "Tari Maharani (Contoh)", kelas: "XII IPS 1", school: "SMAN 3 Harapan" }
    ];
    const picked = sampleProfiles[Math.floor(Math.random() * sampleProfiles.length)];
    nameInput.value = picked.name;
    classInput.value = picked.kelas;
    schoolInput.value = picked.school;
  });

  simLoginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const userData = {
      name: nameInput.value.trim(),
      kelas: classInput.value.trim(),
      school: schoolInput.value.trim(),
      loginAt: new Date().toISOString()
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(userData));
    loginModal.classList.add("hidden");
    renderAuthState();
  });

  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem(STORAGE_KEY);
    renderAuthState();
  });

  renderAuthState();
}

/* =========================================================
   2. ALAT CEK HOAKS CEPAT ([SIMULASI PROTOTIPE AI])
   ========================================================= */
function initHoaxChecker() {
  const newsTextInput = document.getElementById("newsTextInput");
  const analyzeBtn = document.getElementById("analyzeBtn");
  const clearTextBtn = document.getElementById("clearTextBtn");
  const sampleBtns = document.querySelectorAll(".pill-btn");

  const accuracyScoreEl = document.getElementById("accuracyScore");
  const resultHeadlineEl = document.getElementById("resultHeadline");
  const resultDescriptionEl = document.getElementById("resultDescription");
  const riskLevelBadgeEl = document.getElementById("riskLevelBadge");
  const scoreProgressBarEl = document.getElementById("scoreProgressBar");
  const provocativeTagsEl = document.getElementById("provocativeTags");
  const analysisNotesEl = document.getElementById("analysisNotes");

  const sampleTexts = {
    hoax: "VIRAL!! SEBARKAN KE SEMUA GRUP SEKARANG JUGA!! Pemerintah diam-diam membagikan kuota belajar gratis 200GB dan bantuan tunai pelajar tanpa syarat. Klik link hadiah ini sebelum dihapus malam ini!!",
    valid: "Kementerian Pendidikan Dasar dan Menengah mengumumkan jadwal pelaksanaan asesmen nasional jenjang SMA melalui situs resmi kemendikdasmen.go.id. Kepala sekolah diimbau merujuk surat edaran resmi dinas pendidikan setempat."
  };

  sampleBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      const type = btn.getAttribute("data-sample");
      newsTextInput.value = sampleTexts[type] || "";
      analyzeText(newsTextInput.value);
    });
  });

  analyzeBtn.addEventListener("click", () => {
    analyzeText(newsTextInput.value);
  });

  clearTextBtn.addEventListener("click", () => {
    newsTextInput.value = "";
    accuracyScoreEl.textContent = "--";
    resultHeadlineEl.textContent = "Belum Ada Teks Dianalisis";
    resultDescriptionEl.textContent =
      "Masukkan teks berita di samping lalu tekan tombol analisis untuk melihat skor keakuratan simulasi dan deteksi kata provokatif.";
    riskLevelBadgeEl.textContent = "Menunggu Input";
    riskLevelBadgeEl.className = "status-pill neutral";
    scoreProgressBarEl.style.width = "0%";
    provocativeTagsEl.innerHTML = '<span class="empty-note">Belum ada kata provokatif terdeteksi.</span>';
    analysisNotesEl.innerHTML =
      "<li>Sistem akan memeriksa penggunaan huruf kapital berlebihan, tanda seru beruntun, ajakan menyebarkan, dan ketiadaan sumber resmi.</li>";
  });

  function analyzeText(rawText) {
    const text = rawText.trim();
    if (!text) {
      alert("Silakan masukkan teks berita atau pesan berantai terlebih dahulu.");
      return;
    }

    const provocativeDictionary = [
      "viral",
      "sebarkan",
      "sebelum dihapus",
      "geger",
      "terbongkar",
      "diam-diam",
      "tanpa syarat",
      "klik link",
      "hadiah gratis",
      "wajib tahu",
      "darurat",
      "konspirasi",
      "terbukti ampuh",
      "100% asli",
      "buruan"
    ];

    const lowerText = text.toLowerCase();
    const detectedWords = provocativeDictionary.filter((word) => lowerText.includes(word));

    // Perhitungan skor simulasi heuristik (mulai dari 88 poin)
    let score = 88;
    const notes = [];

    if (detectedWords.length > 0) {
      score -= detectedWords.length * 12;
      notes.push(`Ditemukan ${detectedWords.length} kata/frasa bernada sensasional atau provokatif.`);
    } else {
      notes.push("Tidak ditemukan kata kunci clickbait atau ajakan viral yang umum pada pesan berantai.");
    }

    // Cek tanda seru beruntun
    if (/!{2,}/.test(text)) {
      score -= 12;
      notes.push("Terdapat penggunaan tanda seru beruntun (!!) yang sering dipakai untuk memancing kepanikan.");
    }

    // Cek proporsi huruf kapital
    const letters = text.replace(/[^a-zA-Z]/g, "");
    const upperLetters = text.replace(/[^A-Z]/g, "");
    if (letters.length > 15 && upperLetters.length / letters.length > 0.35) {
      score -= 14;
      notes.push("Proporsi huruf kapital terlalu tinggi (>35%), ciri khas pesan berantai emosional.");
    }

    // Cek penyebutan domain resmi (.go.id / .ac.id / kata "resmi")
    if (/(\.go\.id|\.ac\.id|surat edaran|situs resmi)/i.test(text)) {
      score += 8;
      notes.push("Teks mencantumkan rujukan lembaga atau domain resmi yang dapat diverifikasi lebih lanjut.");
    } else {
      score -= 6;
      notes.push("Belum terlihat tautan dokumen atau domain resmi (.go.id / media terverifikasi).");
    }

    score = Math.max(8, Math.min(96, score));

    // Tampilkan hasil
    accuracyScoreEl.textContent = `${score}%`;
    scoreProgressBarEl.style.width = `${score}%`;

    if (score < 45) {
      riskLevelBadgeEl.textContent = "Indikasi Tinggi Hoaks";
      riskLevelBadgeEl.className = "status-pill high-risk";
      resultHeadlineEl.textContent = "[SIMULASI PROTOTIPE AI] Waspada Disinformasi!";
      resultDescriptionEl.textContent =
        "Teks memiliki banyak pola bahasa provokatif dan ciri pesan berantai. Jangan sebarkan sebelum memeriksa di TurnBackHoax.id.";
    } else if (score < 75) {
      riskLevelBadgeEl.textContent = "Perlu Verifikasi Lanjut";
      riskLevelBadgeEl.className = "status-pill medium-risk";
      resultHeadlineEl.textContent = "[SIMULASI PROTOTIPE AI] Klaim Belum Terkonfirmasi";
      resultDescriptionEl.textContent =
        "Sebagian struktur kalimat tampak netral, tetapi minim sumber resmi. Bandingkan dengan minimal dua media kredibel.";
    } else {
      riskLevelBadgeEl.textContent = "Cenderung Informatif";
      riskLevelBadgeEl.className = "status-pill low-risk";
      resultHeadlineEl.textContent = "[SIMULASI PROTOTIPE AI] Gaya Bahasa Relatif Netral";
      resultDescriptionEl.textContent =
        "Tidak ditemukan pola clickbait ekstrem. Tetap pastikan tanggal terbit dan keaslian tautan sumbernya.";
    }

    // Render tag kata provokatif
    if (detectedWords.length > 0) {
      provocativeTagsEl.innerHTML = detectedWords
        .map((w) => `<span class="provocative-tag">${w}</span>`)
        .join("");
    } else {
      provocativeTagsEl.innerHTML =
        '<span class="empty-note">Tidak ada kata provokatif dari kamus simulasi yang terdeteksi.</span>';
    }

    // Render catatan
    analysisNotesEl.innerHTML = notes.map((n) => `<li>${n}</li>`).join("");
  }
}

/* =========================================================
   3. NAVIGASI TAB EDUKASI & KUIS SINGKAT
   ========================================================= */
function initTabs() {
  const tabButtons = document.querySelectorAll(".tab-btn");
  const tabPanels = document.querySelectorAll(".tab-panel");

  tabButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetId = btn.getAttribute("data-tab");

      tabButtons.forEach((b) => {
        b.classList.remove("active");
        b.setAttribute("aria-selected", "false");
      });

      tabPanels.forEach((panel) => {
        panel.classList.remove("active");
      });

      btn.classList.add("active");
      btn.setAttribute("aria-selected", "true");
      const targetPanel = document.getElementById(targetId);
      if (targetPanel) targetPanel.classList.add("active");
    });
  });
}

function initQuiz() {
  const quizData = [
    {
      question: "Kamu menerima pesan WhatsApp bertuliskan 'SEBARKAN KE 10 GRUP SEBELUM DIHAPUS! Kuota gratis 150GB dari Kemendikbud'. Langkah pertama yang paling tepat adalah...",
      options: [
        "Langsung meneruskan ke grup kelas agar teman-teman tidak ketinggalan",
        "Mengklik tautan di pesan tersebut lalu mengisi nomor HP dan password email",
        "Menahan diri, memeriksa situs resmi kemendikdasmen.go.id atau TurnBackHoax.id",
        "Menghapus pesan tanpa memberi tahu teman yang terlanjur membagikannya"
      ],
      answer: 2,
      explanation: "Pesan mendesak dengan iming-iming kuota gratis tanpa domain resmi (.go.id) adalah ciri klasik hoaks/phishing."
    },
    {
      question: "Teknik apa yang paling efektif untuk mengetahui apakah sebuah foto bencana yang viral sebenarnya adalah foto lama dari tahun lalu?",
      options: [
        "Menghitung jumlah komentar di unggahan tersebut",
        "Melakukan Reverse Image Search menggunakan Google Lens atau TinEye",
        "Memperbesar resolusi foto di galeri ponsel",
        "Membaca caption unggahan berulang kali"
      ],
      answer: 1,
      explanation: "Reverse Image Search membantu melacak jejak digital pertama kali gambar diunggah ke internet."
    },
    {
      question: "Manakah yang termasuk ciri utama judul berita clickbait atau disinformasi?",
      options: [
        "Menyebutkan narasumber resmi dan tanggal kejadian secara jelas",
        "Menggunakan huruf kapital berlebihan, tanda seru bertubi-tubi, dan memancing emosi",
        "Menyertakan tautan data statistik dari lembaga riset",
        "Ditulis dengan bahasa baku sesuai kaidah jurnalistik"
      ],
      answer: 1,
      explanation: "Clickbait memicu reaksi emosional (marah/panik/takut) agar pembaca menyebarkan tanpa membaca isi."
    },
    {
      question: "Apa fungsi utama portal Google Fact Check Explorer?",
      options: [
        "Membuat poster kampanye anti-hoaks secara otomatis",
        "Menelusuri klaim viral yang sudah diperiksa oleh berbagai organisasi pemeriksa fakta",
        "Menghapus akun media sosial penyebar hoaks secara langsung",
        "Mengubah berita berbahasa asing menjadi bahasa daerah"
      ],
      answer: 1,
      explanation: "Google Fact Check Explorer mengumpulkan hasil verifikasi dari lembaga cek fakta terakreditasi di seluruh dunia."
    },
    {
      question: "Mengapa prinsip 'Saring Sebelum Sharing' penting diterapkan oleh siswa SMA?",
      options: [
        "Agar menjadi orang pertama yang membagikan berita viral di sekolah",
        "Mencegah penyebaran kepanikan, fitnah, dan menjaga reputasi digital diri sendiri",
        "Supaya kuota internet tidak cepat habis saat membuka media sosial",
        "Karena semua informasi di internet pasti salah"
      ],
      answer: 1,
      explanation: "Memverifikasi informasi sebelum dibagikan melindungi lingkungan sekolah dari disinformasi dan risiko hukum UU ITE."
    }
  ];

  let currentIdx = 0;
  let score = 0;
  let answered = false;

  const progressText = document.getElementById("quizProgressText");
  const scoreLive = document.getElementById("quizScoreLive");
  const questionEl = document.getElementById("quizQuestion");
  const optionsEl = document.getElementById("quizOptions");
  const feedbackEl = document.getElementById("quizFeedback");
  const nextBtn = document.getElementById("nextQuestionBtn");
  const restartBtn = document.getElementById("restartQuizBtn");

  function renderQuestion() {
    answered = false;
    const item = quizData[currentIdx];
    progressText.textContent = `Soal ${currentIdx + 1} dari ${quizData.length}`;
    scoreLive.textContent = `Skor: ${score}`;
    questionEl.textContent = item.question;
    feedbackEl.classList.add("hidden");
    nextBtn.classList.add("hidden");
    restartBtn.classList.add("hidden");

    optionsEl.innerHTML = "";
    item.options.forEach((optText, idx) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "quiz-option-btn";
      btn.textContent = `${String.fromCharCode(65 + idx)}. ${optText}`;
      btn.addEventListener("click", () => handleAnswer(idx, btn));
      optionsEl.appendChild(btn);
    });
  }

  function handleAnswer(selectedIdx, selectedBtn) {
    if (answered) return;
    answered = true;

    const item = quizData[currentIdx];
    const allOptionBtns = optionsEl.querySelectorAll(".quiz-option-btn");
    allOptionBtns.forEach((b) => (b.disabled = true));

    if (selectedIdx === item.answer) {
      score += 20;
      selectedBtn.classList.add("correct");
      feedbackEl.innerHTML = `<strong>Tepat sekali!</strong> ${item.explanation}`;
    } else {
      selectedBtn.classList.add("wrong");
      allOptionBtns[item.answer].classList.add("correct");
      feedbackEl.innerHTML = `<strong>Kurang tepat.</strong> ${item.explanation}`;
    }

    scoreLive.textContent = `Skor: ${score}`;
    feedbackEl.classList.remove("hidden");

    if (currentIdx < quizData.length - 1) {
      nextBtn.classList.remove("hidden");
    } else {
      questionEl.textContent = `Kuis Selesai! Skor Akhir Kamu: ${score} / 100`;
      restartBtn.classList.remove("hidden");
    }
  }

  nextBtn.addEventListener("click", () => {
    currentIdx++;
    renderQuestion();
  });

  restartBtn.addEventListener("click", () => {
    currentIdx = 0;
    score = 0;
    renderQuestion();
  });

  renderQuestion();
}

/* =========================================================
   4. FORMULIR LAPOR HOAKS KE GOOGLE APPS SCRIPT
   ========================================================= */
function initReportForm() {
  const form = document.getElementById("hoaxReportForm");
  const submitBtn = document.getElementById("submitReportBtn");
  const statusMsg = document.getElementById("reportStatusMsg");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const payload = {
      waktu: new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }),
      nama: document.getElementById("reporterName").value.trim(),
      kelas: document.getElementById("reporterClass").value.trim(),
      platform: document.getElementById("hoaxPlatform").value,
      kategori: document.getElementById("hoaxCategory").value,
      tautan: document.getElementById("hoaxLink").value.trim() || "-",
      isi_laporan: document.getElementById("hoaxSummary").value.trim()
    };

    // Jika URL placeholder belum diganti, jalankan simulasi aman
    if (!APPS_SCRIPT_URL || APPS_SCRIPT_URL === "URL_APPS_SCRIPT_ANDA") {
      statusMsg.className = "status-feedback warning";
      statusMsg.innerHTML =
        "<strong>Mode Simulasi Lokal:</strong> Placeholder <code>URL_APPS_SCRIPT_ANDA</code> belum diganti. Data laporan tervalidasi dan siap dikirim setelah Anda menempelkan URL Web App Google Apps Script di <code>script.js</code>.";
      statusMsg.classList.remove("hidden");
      form.reset();
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = "Mengirim Laporan...";

    try {
      // Menggunakan Content-Type text/plain agar Google Apps Script tidak memblokir preflight CORS
      const response = await fetch(APPS_SCRIPT_URL, {
        method: "POST",
        headers: {
          "Content-Type": "text/plain;charset=utf-8"
        },
        body: JSON.stringify(payload)
      });

      const result = await response.json();

      if (result.status === "success") {
        statusMsg.className = "status-feedback success";
        statusMsg.textContent = "Laporan hoaks berhasil tercatat ke Google Sheets. Terima kasih atas kontribusimu!";
        statusMsg.classList.remove("hidden");
        form.reset();
      } else {
        throw new Error(result.message || "Gagal menyimpan data.");
      }
    } catch (error) {
      statusMsg.className = "status-feedback error";
      statusMsg.textContent = `Terjadi kendala saat mengirim laporan: ${error.message}`;
      statusMsg.classList.remove("hidden");
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = "Kirim Laporan ke Google Sheets";
    }
  });
}
